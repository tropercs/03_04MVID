#include <string>
#include <vector>

struct Float3 {
  float x, y, z;
};

class Entity;

class World {
public:
  // Get a list of all the characters in the world.
  std::vector<Entity *> const &GetCharacters();
  // Get a list of all the doors in the world.
  std::vector<Entity *> const &GetDoors();
};

class Entity {
public:
  World &GetWorld();
  // Returns the current 3D position (in meters) of the entity within the world
  Float3 GetPosition();
  // Returns the current velocity of the character (in meters per second)
  Float3 GetVelocity();

  // Start playing an animation. Animations stop playing (freezing on their
  // final frame) when complete.
  void StartAnimation(std::string const &anim);
  bool IsAnimationComplete();
  // Get the duration of an animation, in seconds
  float GetAnimationDuration(std::string const &anim);
  // Called every frame with the time elapsed since previous frame, in seconds
  virtual void Update(float timestep) = 0;
};

// Represents an automatic door which should open for characters as they
// approach. The following animations are available:
//
// IDLE_CLOSED, IDLE_OPEN, OPENING, CLOSING
//
class Door : public Entity {
public:
  // Candidate to implement. Must try to ensure door is open whenever a
  // character approaches within 1 meter, and is closed otherwise, without
  // snapping animations.
  virtual void Update(float timestep) override�
};
